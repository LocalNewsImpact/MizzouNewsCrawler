"""Shared text utilities."""
