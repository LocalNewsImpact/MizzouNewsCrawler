"""Canonical organization queries for the public API."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from enum import StrEnum

from backfield_db import (
    StylebookOrganizationCanonical,
    StylebookOrganizationMeta,
    SubstrateArticle,
    SubstrateOrganization,
    SubstrateOrganizationMention,
    SubstrateOrganizationMentionOccurrence,
)
from pydantic import BaseModel, Field
from sqlalchemy import case, exists, literal
from sqlalchemy.sql.elements import ColumnElement
from sqlmodel import Session, col, func, select

from backfield_entities.catalog.canonical_meta import AttrClause
from backfield_entities.public.articles import ArticleMetaClause, PublicArticleOut
from backfield_entities.public.canonical_metadata import (
    PublicCanonicalMetaOut,
    append_attr_filters,
    load_meta_by_canonical_ids,
)
from backfield_entities.public.entity_articles import (
    collect_mention_article_pairs,
    paginate_public_articles_from_mention_pairs,
)
from backfield_entities.public.entity_counts import PublicEntityCountsOut
from backfield_entities.public.mention_evidence import (
    PublicMentionEvidenceOut,
    organization_evidence_by_mention_id,
)
from backfield_entities.public.mention_filters import (
    PublicEntityMentionListParams,
    apply_entity_mention_list_filters,
)
from backfield_entities.public.nature_filters import normalize_natures
from backfield_entities.public.stylebook_scope import (
    get_public_organization_canonical,
    stylebook_slugs_by_id,
)


def _escape_ilike_metacharacters(value: str) -> str:
    return value.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


def _canonical_list_sort_key():
    return func.lower(col(StylebookOrganizationCanonical.label))


class PublicOrganizationSort(StrEnum):
    label = "label"
    recent = "recent"


class PublicOrganizationOut(BaseModel):
    id: str
    slug: str
    label: str
    stylebook_slug: str | None = None
    organization_type: str | None = None
    counts: PublicEntityCountsOut = PublicEntityCountsOut()
    metadata: list[PublicCanonicalMetaOut] = Field(default_factory=list)


class PublicOrganizationMentionArticleOut(BaseModel):
    id: int
    headline: str
    url: str | None = None
    pub_date: date | None = None


class PublicOrganizationMentionOut(BaseModel):
    mention_id: int
    article: PublicOrganizationMentionArticleOut
    label: str
    organization_type: str | None = None
    nature: str | None = None
    role_in_story: str | None = None
    evidence: PublicMentionEvidenceOut | None = None


@dataclass(frozen=True)
class PublicOrganizationSearchParams:
    q: str | None = None
    organization_type: str | None = None
    natures: tuple[str, ...] = ()
    min_mentions: int = 0
    attr_clauses: tuple[AttrClause, ...] = ()
    include_metadata: bool = False
    sort: PublicOrganizationSort = PublicOrganizationSort.label
    limit: int = 25
    offset: int = 0


def _organization_to_public_out(
    canon: StylebookOrganizationCanonical,
    *,
    mention_count: int = 0,
    story_count: int = 0,
    stylebook_slug: str | None = None,
    metadata: list[PublicCanonicalMetaOut] | None = None,
) -> PublicOrganizationOut:
    return PublicOrganizationOut(
        id=str(canon.id),
        slug=str(canon.slug),
        label=str(canon.label),
        stylebook_slug=stylebook_slug,
        organization_type=canon.organization_type,
        counts=PublicEntityCountsOut(mentions=mention_count, stories=story_count),
        metadata=list(metadata or []),
    )


def _mention_counts_by_canonical(
    session: Session,
    *,
    project_id: int,
    canonical_ids: list[str],
) -> dict[str, int]:
    if not canonical_ids:
        return {}
    rows = session.exec(
        select(
            SubstrateOrganization.stylebook_organization_canonical_id,
            func.count(col(SubstrateOrganizationMention.id)),
        )
        .select_from(SubstrateOrganizationMention)
        .join(
            SubstrateOrganization,
            SubstrateOrganization.id == SubstrateOrganizationMention.organization_id,
        )
        .where(
            SubstrateOrganization.project_id == project_id,
            col(SubstrateOrganization.stylebook_organization_canonical_id).in_(canonical_ids),
            SubstrateOrganizationMention.deleted == False,  # noqa: E712
        )
        .group_by(SubstrateOrganization.stylebook_organization_canonical_id)
    ).all()
    return {str(cid): int(cnt) for cid, cnt in rows if cid is not None}


def _story_counts_by_canonical(
    session: Session,
    *,
    project_id: int,
    canonical_ids: list[str],
) -> dict[str, int]:
    if not canonical_ids:
        return {}
    rows = session.exec(
        select(
            SubstrateOrganization.stylebook_organization_canonical_id,
            func.count(func.distinct(SubstrateOrganizationMention.article_id)),
        )
        .select_from(SubstrateOrganizationMention)
        .join(
            SubstrateOrganization,
            SubstrateOrganization.id == SubstrateOrganizationMention.organization_id,
        )
        .where(
            SubstrateOrganization.project_id == project_id,
            col(SubstrateOrganization.stylebook_organization_canonical_id).in_(canonical_ids),
            SubstrateOrganizationMention.deleted == False,  # noqa: E712
        )
        .group_by(SubstrateOrganization.stylebook_organization_canonical_id)
    ).all()
    return {str(cid): int(cnt) for cid, cnt in rows if cid is not None}


def _organization_filters(
    *,
    stylebook_id: int,
    project_id: int,
    params: PublicOrganizationSearchParams,
) -> list[ColumnElement[bool]]:
    filters: list[ColumnElement[bool]] = [
        StylebookOrganizationCanonical.stylebook_id == stylebook_id,
        StylebookOrganizationCanonical.status == "active",
    ]
    q_text = (params.q or "").strip()
    if q_text:
        esc = _escape_ilike_metacharacters(q_text)
        term = f"%{esc}%"
        filters.append(col(StylebookOrganizationCanonical.label).ilike(term, escape="\\"))
    org_type = (params.organization_type or "").strip()
    if org_type:
        filters.append(col(StylebookOrganizationCanonical.organization_type) == org_type)
    natures = normalize_natures(params.natures)
    if natures:
        filters.append(
            exists().where(
                SubstrateOrganization.stylebook_organization_canonical_id
                == StylebookOrganizationCanonical.id,
                SubstrateOrganization.project_id == project_id,
                SubstrateOrganizationMention.organization_id == SubstrateOrganization.id,
                SubstrateOrganizationMention.deleted == False,  # noqa: E712
                col(SubstrateOrganizationMention.nature).in_(natures),
            )
        )
    if params.min_mentions > 0:
        min_stmt = (
            select(SubstrateOrganization.stylebook_organization_canonical_id)
            .select_from(SubstrateOrganizationMention)
            .join(
                SubstrateOrganization,
                SubstrateOrganization.id == SubstrateOrganizationMention.organization_id,
            )
            .where(
                SubstrateOrganization.project_id == project_id,
                col(SubstrateOrganization.stylebook_organization_canonical_id).is_not(None),
                SubstrateOrganizationMention.deleted == False,  # noqa: E712
            )
            .group_by(SubstrateOrganization.stylebook_organization_canonical_id)
            .having(func.count(col(SubstrateOrganizationMention.id)) >= params.min_mentions)
        )
        filters.append(col(StylebookOrganizationCanonical.id).in_(min_stmt))
    append_attr_filters(
        filters,
        meta_model=StylebookOrganizationMeta,
        canonical_fk_attr="stylebook_organization_canonical_id",
        canonical_id_column=StylebookOrganizationCanonical.id,
        attr_clauses=params.attr_clauses,
    )
    return filters


def _activity_order_columns(*, project_id: int) -> tuple:
    max_sub_updated = (
        select(func.max(col(SubstrateOrganization.updated_at)))
        .where(
            col(SubstrateOrganization.stylebook_organization_canonical_id)
            == col(StylebookOrganizationCanonical.id),
            SubstrateOrganization.project_id == project_id,
        )
        .scalar_subquery()
    )
    canon_updated = col(StylebookOrganizationCanonical.updated_at)
    coalesced = func.coalesce(max_sub_updated, canon_updated)
    activity = case(
        (coalesced > canon_updated, coalesced),
        else_=canon_updated,
    )
    sort_key_col = _canonical_list_sort_key()
    return (activity.desc(), sort_key_col.asc(), col(StylebookOrganizationCanonical.id).asc())


def search_public_organizations(
    session: Session,
    *,
    stylebook_id: int,
    project_id: int,
    params: PublicOrganizationSearchParams,
) -> tuple[list[PublicOrganizationOut], int]:
    filters = _organization_filters(
        stylebook_id=stylebook_id,
        project_id=project_id,
        params=params,
    )
    total = int(
        session.scalar(
            select(func.count()).select_from(StylebookOrganizationCanonical).where(*filters)
        )
        or 0
    )

    label_lower = func.lower(col(StylebookOrganizationCanonical.label))
    label_col = col(StylebookOrganizationCanonical.label)
    sort_key_col = _canonical_list_sort_key()
    q_text = (params.q or "").strip()
    if params.sort == PublicOrganizationSort.recent:
        order_by = _activity_order_columns(project_id=project_id)
    elif q_text:
        q_lower = q_text.lower()
        esc = _escape_ilike_metacharacters(q_text)
        prefix_pat = f"{esc}%"
        rank = case(
            (label_lower == literal(q_lower), 0),
            (label_col.ilike(prefix_pat, escape="\\"), 1),
            else_=2,
        )
        order_by = (
            rank.asc(),
            func.length(label_col).asc(),
            sort_key_col.asc(),
            col(StylebookOrganizationCanonical.id).asc(),
        )
    else:
        order_by = (sort_key_col.asc(), col(StylebookOrganizationCanonical.id).asc())

    rows = list(
        session.exec(
            select(StylebookOrganizationCanonical)
            .where(*filters)
            .order_by(*order_by)
            .offset(params.offset)
            .limit(params.limit)
        ).all()
    )
    canonical_ids = [str(row.id) for row in rows if row.id is not None]
    mention_counts = _mention_counts_by_canonical(
        session,
        project_id=project_id,
        canonical_ids=canonical_ids,
    )
    story_counts = _story_counts_by_canonical(
        session,
        project_id=project_id,
        canonical_ids=canonical_ids,
    )
    stylebook_slug = stylebook_slugs_by_id(session, {stylebook_id}).get(stylebook_id)
    meta_by_id: dict[str, list[PublicCanonicalMetaOut]] = {}
    if params.include_metadata:
        meta_by_id = load_meta_by_canonical_ids(
            session,
            meta_model=StylebookOrganizationMeta,
            canonical_fk_attr="stylebook_organization_canonical_id",
            canonical_ids=canonical_ids,
        )
    items = [
        _organization_to_public_out(
            row,
            mention_count=mention_counts.get(str(row.id), 0),
            story_count=story_counts.get(str(row.id), 0),
            stylebook_slug=stylebook_slug,
            metadata=meta_by_id.get(str(row.id), []),
        )
        for row in rows
    ]
    return items, total


def get_public_organization(
    session: Session,
    *,
    stylebook_id: int,
    project_id: int,
    organization_id: str,
) -> PublicOrganizationOut | None:
    canon = get_public_organization_canonical(
        session,
        stylebook_id=stylebook_id,
        organization_id=organization_id,
    )
    if canon is None:
        return None
    mention_counts = _mention_counts_by_canonical(
        session,
        project_id=project_id,
        canonical_ids=[str(canon.id)],
    )
    story_counts = _story_counts_by_canonical(
        session,
        project_id=project_id,
        canonical_ids=[str(canon.id)],
    )
    stylebook_slug = stylebook_slugs_by_id(session, {stylebook_id}).get(stylebook_id)
    meta_by_id = load_meta_by_canonical_ids(
        session,
        meta_model=StylebookOrganizationMeta,
        canonical_fk_attr="stylebook_organization_canonical_id",
        canonical_ids=[str(canon.id)],
    )
    return _organization_to_public_out(
        canon,
        mention_count=mention_counts.get(str(canon.id), 0),
        story_count=story_counts.get(str(canon.id), 0),
        stylebook_slug=stylebook_slug,
        metadata=meta_by_id.get(str(canon.id), []),
    )


def list_public_organization_mentions(
    session: Session,
    *,
    stylebook_id: int,
    project_id: int,
    organization_id: str,
    params: PublicEntityMentionListParams | None = None,
) -> tuple[list[PublicOrganizationMentionOut], int] | None:
    list_params = params or PublicEntityMentionListParams()
    canon = get_public_organization_canonical(
        session,
        stylebook_id=stylebook_id,
        organization_id=organization_id,
    )
    if canon is None:
        return None

    base_where: list[ColumnElement[bool]] = [
        SubstrateOrganization.stylebook_organization_canonical_id == str(canon.id),
        SubstrateOrganization.project_id == project_id,
        SubstrateOrganizationMention.deleted == False,  # noqa: E712
        SubstrateArticle.project_id == project_id,
        SubstrateArticle.deleted == False,  # noqa: E712
    ]

    count_stmt = (
        select(func.count())
        .select_from(SubstrateOrganizationMention)
        .join(SubstrateArticle, SubstrateArticle.id == SubstrateOrganizationMention.article_id)
        .join(
            SubstrateOrganization,
            SubstrateOrganization.id == SubstrateOrganizationMention.organization_id,
        )
        .where(*base_where)
    )
    count_stmt = apply_entity_mention_list_filters(
        count_stmt,
        params=list_params,
        mention_nature_col=SubstrateOrganizationMention.nature,
        mention_id_col=SubstrateOrganizationMention.id,
        occurrence_model=SubstrateOrganizationMentionOccurrence,
        mention_fk_column="organization_mention_id",
    )
    total = int(session.scalar(count_stmt) or 0)

    descending = list_params.sort_direction != "asc"
    if list_params.sort == "article":
        headline_sort = col(SubstrateArticle.headline)
        order_by = headline_sort.desc() if descending else headline_sort.asc()
    else:
        ts = col(SubstrateOrganizationMention.updated_at)
        order_by = ts.desc() if descending else ts.asc()

    select_stmt = (
        select(SubstrateOrganizationMention, SubstrateArticle, SubstrateOrganization)
        .join(SubstrateArticle, SubstrateArticle.id == SubstrateOrganizationMention.article_id)
        .join(
            SubstrateOrganization,
            SubstrateOrganization.id == SubstrateOrganizationMention.organization_id,
        )
        .where(*base_where)
    )
    select_stmt = apply_entity_mention_list_filters(
        select_stmt,
        params=list_params,
        mention_nature_col=SubstrateOrganizationMention.nature,
        mention_id_col=SubstrateOrganizationMention.id,
        occurrence_model=SubstrateOrganizationMentionOccurrence,
        mention_fk_column="organization_mention_id",
    )
    triples = list(
        session.exec(
            select_stmt.order_by(order_by)
            .offset(list_params.offset)
            .limit(list_params.limit)
        ).all()
    )
    mention_ids = [int(m.id) for m, _, _ in triples if m.id is not None]  # type: ignore[union-attr]
    evidence_by_id = organization_evidence_by_mention_id(session, mention_ids)

    items: list[PublicOrganizationMentionOut] = []
    for mention, article, organization in triples:
        if mention.id is None or article.id is None:
            continue
        mid = int(mention.id)
        items.append(
            PublicOrganizationMentionOut(
                mention_id=mid,
                article=PublicOrganizationMentionArticleOut(
                    id=int(article.id),
                    headline=str(article.headline),
                    url=article.url,
                    pub_date=article.pub_date,
                ),
                label=str(organization.name),
                organization_type=organization.organization_type,
                nature=mention.nature,
                role_in_story=mention.role_in_story,
                evidence=evidence_by_id.get(mid),
            )
        )
    return items, total


def list_public_organization_articles(
    session: Session,
    *,
    stylebook_id: int,
    project_id: int,
    organization_id: str,
    limit: int = 25,
    offset: int = 0,
    natures: tuple[str, ...] = (),
    meta_clauses: tuple[ArticleMetaClause, ...] = (),
    author: str | None = None,
    external_source: str | None = None,
    pub_date_from: date | None = None,
    pub_date_to: date | None = None,
) -> tuple[list[PublicArticleOut], int] | None:
    canon = get_public_organization_canonical(
        session,
        stylebook_id=stylebook_id,
        organization_id=organization_id,
    )
    if canon is None:
        return None

    pairs = collect_mention_article_pairs(
        session,
        mention_model=SubstrateOrganizationMention,
        entity_model=SubstrateOrganization,
        mention_entity_fk=SubstrateOrganizationMention.organization_id,
        entity_canonical_col=SubstrateOrganization.stylebook_organization_canonical_id,
        canonical_id=str(canon.id),
        project_id=project_id,
        natures=natures,
        meta_clauses=meta_clauses,
        author=author,
        external_source=external_source,
        pub_date_from=pub_date_from,
        pub_date_to=pub_date_to,
    )
    items, total = paginate_public_articles_from_mention_pairs(
        session,
        pairs=pairs,
        limit=limit,
        offset=offset,
    )
    return items, total
