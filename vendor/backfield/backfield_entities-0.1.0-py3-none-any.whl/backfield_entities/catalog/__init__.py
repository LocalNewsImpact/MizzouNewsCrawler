"""Stylebook catalog query helpers."""
