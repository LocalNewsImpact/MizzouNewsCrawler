"""Person extract review routing: LLM labels plus deterministic overrides."""

from __future__ import annotations

import re
from typing import Any, Literal

from backfield_entities.entities.person.types import normalize_person_text

ReviewHandling = Literal["none", "flag_review", "auto_defer"]

REVIEW_HANDLING_NONE: ReviewHandling = "none"
REVIEW_HANDLING_FLAG: ReviewHandling = "flag_review"
REVIEW_HANDLING_AUTO_DEFER: ReviewHandling = "auto_defer"

REASON_CHILD = "child"
REASON_ANIMAL = "animal"
REASON_NOT_A_PERSON = "not_a_person"
REASON_STAGE_NAME_OR_ALIAS = "stage_name_or_alias"
REASON_PSEUDONYM = "pseudonym"
REASON_FIRST_NAME_ONLY = "first_name_only"

AUTO_WAIVE_REASON_CODES: frozenset[str] = frozenset(
    {REASON_CHILD, REASON_ANIMAL, REASON_NOT_A_PERSON}
)
FLAG_REVIEW_REASON_CODES: frozenset[str] = frozenset(
    {REASON_STAGE_NAME_OR_ALIAS, REASON_PSEUDONYM, REASON_FIRST_NAME_ONLY}
)

_DEFAULT_MESSAGES: dict[str, str] = {
    REASON_CHILD: "Identified as a child",
    REASON_ANIMAL: "Identified as an animal",
    REASON_NOT_A_PERSON: "Not a person — organization, institution, role label, or product",
    REASON_STAGE_NAME_OR_ALIAS: "Stage name or alias — confirm full identity before linking",
    REASON_PSEUDONYM: "Descriptive pseudonym — defer linking until a legal identity is known",
    REASON_FIRST_NAME_ONLY: "First name only — confirm full identity before linking",
}

_INFERRED_SURNAME_REVIEW_MESSAGE = (
    "Surname inferred from a family reference — confirm full identity before linking"
)

_VALID_HANDLING: frozenset[str] = frozenset(
    {REVIEW_HANDLING_NONE, REVIEW_HANDLING_FLAG, REVIEW_HANDLING_AUTO_DEFER}
)
_VALID_REASON_CODES: frozenset[str] = AUTO_WAIVE_REASON_CODES | FLAG_REVIEW_REASON_CODES

_FIRST_NAME_ONLY_RE = re.compile(r"^[A-Z][a-z]{1,}$")
_PSEUDONYM_IN_PLACE_RE = re.compile(
    r"^(?P<descriptor>.+?)\s+in\s+(?P<place>[A-Za-z][\w\s\-.'']+)$",
    re.IGNORECASE,
)
_DESCRIPTIVE_PSEUDONYM_WORD_RE = re.compile(
    r"(ing|er|or|ist|ian|heart|voice|teller|whistle|source)$",
    re.IGNORECASE,
)
_LEGISLATION_RE = re.compile(
    r"\b("
    r"act|law|statute|ordinance|legislation|amendment|bill|treaty|decree|resolution"
    r")\b.*\b\d{4}\b|\brecords act\b|\bact of \d{4}\b",
    re.IGNORECASE,
)
_SCHOOL_OR_CAMPUS_RE = re.compile(
    r"\b("
    r"academy|high school|elementary school|middle school|prep school|primary school|"
    r"secondary school|charter school|school district|university|college|"
    r"community college|medical school|law school|business school"
    r")\b",
    re.IGNORECASE,
)
_INSTITUTION_RE = re.compile(
    r"\b("
    r"office of|department of|bureau of|bureau|agency|administration|authority|commission|"
    r"board of|division of|corporation|company|foundation|institute|association|"
    r"union|medical center|police department|fire department|school board|"
    r"county clerk|state attorney|attorney general|city council|"
    r"chamber of commerce|public library|memorial hospital|"
    r"gaming board|medical board|safety board|transportation board|"
    r"ancestors|explosives|firearms"
    r")\b",
    re.IGNORECASE,
)
_BOARD_OR_COMMISSION_SUFFIX_RE = re.compile(r"\b(board|commission)\s*$", re.IGNORECASE)
_ROLE_NOUNS = (
    "agent",
    "officer",
    "official",
    "officials",
    "authorities",
    "spokesperson",
    "detective",
    "prosecutor",
    "inspector",
    "commissioner",
    "employee",
    "employees",
    "worker",
    "workers",
    "staff",
    "personnel",
    "representative",
    "representatives",
    "investigator",
    "investigators",
    "supervisor",
    "supervisors",
    "regulator",
    "regulators",
)
_ROLE_ONLY_ENDING_RE = re.compile(
    r"\b(?:" + "|".join(_ROLE_NOUNS) + r")\s*$",
    re.IGNORECASE,
)
_AGE_DESCRIPTOR_RE = re.compile(
    r"^(?:an?\s+)?\d{1,3}[- ]year[- ]old"
    r"(?:\s+(?:man|woman|boy|girl|male|female|student|teen(?:ager)?))?\s*$",
    re.IGNORECASE,
)
_VAGUE_ARTICLE_ROLE_RE = re.compile(
    r"^(?:an?\s+|the\s+)?(?:\d+\s+)?(?:unidentified|unknown|unnamed|unamed)\s+"
    r"(?:man|woman|boy|girl|male|female|person|suspect|victim|driver|passenger|shooter|gunman)\s*$",
    re.IGNORECASE,
)
_VAGUE_DEMOGRAPHIC_ROLE_RE = re.compile(
    r"^(?:an?\s+|the\s+)?(?:(?:\d+|one|two|three|four|five|six|seven|eight|nine|ten)\s+)?(?:"
    r"man|men|woman|women|boy|girl|male|female|person|people|victim|victims|suspect|suspects|"
    r"driver|passenger|pedestrian|bystander|witness|teen(?:ager)?|youth|child|children|student|resident"
    r")s?\s*$",
    re.IGNORECASE,
)
_VAGUE_QUALIFIER_ROLE_RE = re.compile(
    r"^(?:young|old|elderly|unidentified|unknown|unnamed|unamed)\s+"
    r"(?:man|woman|person|male|female|suspect|victim|driver|passenger|shooter|gunman)s?\s*$",
    re.IGNORECASE,
)
_VAGUE_STANDALONE_ROLE_RE = re.compile(
    r"^(?:the\s+)?(?:victim|suspect|driver|passenger|shooter|gunman|assailant|intruder|robber|witness|bystander)s?\s*$",
    re.IGNORECASE,
)
_SKIP_PERSON_EXTRACT_PREFIX = "non-qualifying person name:"
_GENERIC_AUTHORITY_RE = re.compile(
    r"\b("
    r"federal|state|local|city|county|national"
    r")\s+(authorities|officials|agents|officers|law enforcement|regulators)\b",
    re.IGNORECASE,
)
_AGENCY_ACRONYM_RE = re.compile(
    r"^(?:ATF|ICE|FBI|CIA|DHS|DEA|EPA|FDA|CDC|IRS|TSA|CBP|NTSB|SEC|FTC|OSHA|FEMA|USDA|"
    r"NOAA|NSF|GAO|HUD|DOJ|DOL|DOT|HHS|CMS|NIH|USGS|INS|CBP)$",
    re.IGNORECASE,
)
_CORPORATE_MARKER_RE = re.compile(
    r"&|\b(?:inc|llc|corp|ltd|co)\.?\s*$",
    re.IGNORECASE,
)
_AI_OR_PRODUCT_RE = re.compile(
    r"\b(?:chatgpt|gemini|copilot|claude|openai|anthropic)\b|\bAI\s*$",
    re.IGNORECASE,
)
_COMMA_LIST_INSTITUTION_RE = re.compile(r"^[^,]+,\s*[^,]+,\s*[^,]+")
_BROADCAST_CALL_SIGN_RE = re.compile(
    r"^(?:W|K)[A-Z]{2,3}(?:\s+\d{1,4})?(?:\s+(?:AM|FM))?$",
    re.IGNORECASE,
)
_TRAILING_CHANNEL_NUMBER_RE = re.compile(r"\b\d{3,4}\s*$")
_PLACE_VENUE_RE = re.compile(
    r"\b("
    r"airport|international airport|regional airport|airfield|air base|"
    r"train station|bus station|transit center|convention center|"
    r"stadium|arena|ballpark|speedway|raceway|terminal"
    r")\b",
    re.IGNORECASE,
)
_LEGISLATIVE_BODY_RE = re.compile(
    r"\b("
    r"general assembly|legislative assembly|state legislature|national legislature|"
    r"provincial legislature|parliament|house of representatives|"
    r"city council|county board|board of supervisors"
    r")\b",
    re.IGNORECASE,
)
_GEOGRAPHIC_SUFFIX_RE = re.compile(
    r"\b(aires|angeles|orleans|borough|burgh|shire)\s*$",
    re.IGNORECASE,
)
_SAN_PREFIX_PLACE_RE = re.compile(r"^San\s+[A-Z]", re.IGNORECASE)
_KNOWN_PLACE_NAME_KEYS: frozenset[str] = frozenset(
    {
        "anchorage",
        "atlanta",
        "austin",
        "baltimore",
        "birmingham",
        "boston",
        "buffalo",
        "charlotte",
        "chicago",
        "cincinnati",
        "cleveland",
        "columbus",
        "dallas",
        "denver",
        "detroit",
        "honolulu",
        "houston",
        "indianapolis",
        "jacksonville",
        "kansas city",
        "las vegas",
        "lexington",
        "louisville",
        "memphis",
        "miami",
        "milwaukee",
        "minneapolis",
        "nashville",
        "omaha",
        "orlando",
        "philadelphia",
        "phoenix",
        "pittsburgh",
        "portland",
        "raleigh",
        "richmond",
        "sacramento",
        "seattle",
        "tampa",
        "toledo",
        "tucson",
        "tulsa",
        "wichita",
        "buenos aires",
        "hong kong",
        "los angeles",
        "new york",
        "san antonio",
        "san diego",
        "san francisco",
        "san jose",
        "salt lake city",
        "st louis",
        "saint louis",
    }
)


def default_review_message(code: str) -> str:
    return _DEFAULT_MESSAGES.get(code, "Needs review before canonical linking")


def is_auto_waive_review_code(code: str | None) -> bool:
    return str(code or "").strip() in AUTO_WAIVE_REASON_CODES


def is_flag_review_code(code: str | None) -> bool:
    return str(code or "").strip() in FLAG_REVIEW_REASON_CODES


def review_reason_dict(*, code: str, message: str | None = None) -> dict[str, str]:
    clean_code = str(code).strip()
    msg = (message or "").strip() or default_review_message(clean_code)
    return {"code": clean_code, "message": msg}


def _normalize_handling(value: Any) -> ReviewHandling:
    if not isinstance(value, str):
        return REVIEW_HANDLING_NONE
    s = value.strip().lower()
    if s in _VALID_HANDLING:
        return s  # type: ignore[return-value]
    return REVIEW_HANDLING_NONE


def _normalize_reason_code(value: Any) -> str | None:
    if not isinstance(value, str):
        return None
    s = value.strip().lower()
    return s if s in _VALID_REASON_CODES else None


def _optional_message(value: Any) -> str | None:
    if isinstance(value, str):
        cleaned = value.strip()
        return cleaned or None
    return None


def _handling_for_reason(code: str) -> ReviewHandling:
    if code in AUTO_WAIVE_REASON_CODES:
        return REVIEW_HANDLING_AUTO_DEFER
    if code in FLAG_REVIEW_REASON_CODES:
        return REVIEW_HANDLING_FLAG
    return REVIEW_HANDLING_NONE


def parse_review_fields_from_entry(
    entry: dict[str, Any],
) -> tuple[ReviewHandling, str | None, str | None]:
    """Read LLM review fields from a consolidated ``people`` entry."""
    handling = _normalize_handling(entry.get("review_handling"))
    code = _normalize_reason_code(entry.get("review_reason_code"))
    message = _optional_message(entry.get("review_message"))
    if code is not None and handling == REVIEW_HANDLING_NONE:
        handling = _handling_for_reason(code)
    if code is not None and not message:
        message = default_review_message(code)
    if handling != REVIEW_HANDLING_NONE and code is None:
        handling = REVIEW_HANDLING_NONE
    return handling, code, message


def looks_like_first_name_only_token(name: str) -> bool:
    """Heuristic: short single Title-case token (e.g. ``Maria``), not mononyms like ``Prince``."""
    token = name.strip()
    if not token or " " in token or "." in token:
        return False
    if len(token) > 5:
        return False
    return _FIRST_NAME_ONLY_RE.fullmatch(token) is not None


def _descriptor_words_look_descriptive(descriptor: str) -> bool:
    for part in re.split(r"[\s\-]+", descriptor):
        token = part.strip()
        if token and _DESCRIPTIVE_PSEUDONYM_WORD_RE.search(token):
            return True
    return False


def _place_name_key(name: str) -> str:
    return normalize_person_text(name)


def _looks_like_place_or_venue_name(name: str) -> bool:
    token = name.strip()
    if not token:
        return False
    if _PLACE_VENUE_RE.search(token):
        return True
    if _SAN_PREFIX_PLACE_RE.match(token):
        return True
    key = _place_name_key(token)
    if key in _KNOWN_PLACE_NAME_KEYS:
        return True
    parts = [p for p in re.split(r"\s+", token) if p]
    if len(parts) >= 2 and _GEOGRAPHIC_SUFFIX_RE.search(parts[-1]):
        return True
    return False


def _looks_like_personal_name(name: str) -> bool:
    """True for conventional first/last personal names without institutional or role tokens."""
    token = name.strip()
    if not token or _ROLE_ONLY_ENDING_RE.search(token):
        return False
    if (
        _SCHOOL_OR_CAMPUS_RE.search(token)
        or _INSTITUTION_RE.search(token)
        or _BOARD_OR_COMMISSION_SUFFIX_RE.search(token)
        or _CORPORATE_MARKER_RE.search(token)
        or _TRAILING_CHANNEL_NUMBER_RE.search(token)
        or _PLACE_VENUE_RE.search(token)
        or _LEGISLATIVE_BODY_RE.search(token)
        or _looks_like_place_or_venue_name(token)
    ):
        return False
    name_tokens: list[str] = []
    for part in re.split(r"\s+", token):
        if not part or not part[0].isalpha():
            continue
        if part.lower() in _ROLE_NOUNS:
            return False
        if part[0].isupper():
            name_tokens.append(part)
    return len(name_tokens) >= 2


def looks_like_vague_person_descriptor(name: str) -> bool:
    """Heuristic: age/demographic/role labels with no personal name."""
    token = name.strip()
    if not token:
        return False
    if _AGE_DESCRIPTOR_RE.fullmatch(token):
        return True
    if _VAGUE_ARTICLE_ROLE_RE.fullmatch(token):
        return True
    if _VAGUE_DEMOGRAPHIC_ROLE_RE.fullmatch(token):
        return True
    if _VAGUE_QUALIFIER_ROLE_RE.fullmatch(token):
        return True
    if _VAGUE_STANDALONE_ROLE_RE.fullmatch(token):
        return True
    return False


def should_skip_person_extract_entry(
    name: str,
    *,
    title: str | None = None,
    affiliation: str | None = None,
) -> bool:
    """True when PersonExtract should omit a row instead of emitting a person record."""
    if looks_like_vague_person_descriptor(name):
        return True
    return looks_like_non_person_entity(name, title=title, affiliation=affiliation)


def skip_person_extract_entry_error(name: str) -> str:
    return f"{_SKIP_PERSON_EXTRACT_PREFIX} {name!r}"


def is_skippable_person_extract_error(message: str) -> bool:
    return message.startswith(_SKIP_PERSON_EXTRACT_PREFIX)


def looks_like_non_person_entity(
    name: str,
    *,
    title: str | None = None,
    affiliation: str | None = None,
) -> bool:
    """Heuristic: institutions, role labels, agencies, and products mis-tagged as people."""
    token = name.strip()
    if not token:
        return False
    if looks_like_vague_person_descriptor(token):
        return True
    if _LEGISLATION_RE.search(token):
        return True
    if _SCHOOL_OR_CAMPUS_RE.search(token):
        return True
    if _INSTITUTION_RE.search(token):
        return True
    if _BOARD_OR_COMMISSION_SUFFIX_RE.search(token):
        return True
    if _GENERIC_AUTHORITY_RE.search(token):
        return True
    if _AGENCY_ACRONYM_RE.fullmatch(token):
        return True
    if _CORPORATE_MARKER_RE.search(token):
        return True
    if _AI_OR_PRODUCT_RE.search(token):
        return True
    if _COMMA_LIST_INSTITUTION_RE.match(token):
        return True
    if _BROADCAST_CALL_SIGN_RE.fullmatch(token):
        return True
    if _TRAILING_CHANNEL_NUMBER_RE.search(token):
        return True
    if _ROLE_ONLY_ENDING_RE.search(token):
        return True
    if _PLACE_VENUE_RE.search(token):
        return True
    if _LEGISLATIVE_BODY_RE.search(token):
        return True
    if _looks_like_place_or_venue_name(token):
        return True
    title_clean = (title or "").strip()
    if title_clean and title_clean.casefold() == token.casefold():
        return True
    aff_clean = (affiliation or "").strip()
    if aff_clean and token.casefold() in aff_clean.casefold() and len(token.split()) >= 3:
        return True
    if _looks_like_personal_name(token):
        return False
    return False


def looks_like_descriptive_pseudonym(name: str) -> bool:
    """Heuristic: anonymous-source style names such as ``TRUTH-TELLER IN ARKANSAS``."""
    token = name.strip()
    if not token:
        return False
    match = _PSEUDONYM_IN_PLACE_RE.match(token)
    if match is None:
        return False
    descriptor = match.group("descriptor").strip()
    if not descriptor:
        return False
    if "-" in descriptor:
        return True
    if descriptor.isupper():
        return True
    words = descriptor.split()
    if len(words) >= 3:
        return True
    return _descriptor_words_look_descriptive(descriptor)


def person_name_is_descriptive_pseudonym(
    *,
    person_name: str,
    reason_code: str | None = None,
    source_details: dict[str, Any] | None = None,
) -> bool:
    code = str(reason_code or "").strip()
    details = source_details if isinstance(source_details, dict) else {}
    if code == REASON_PSEUDONYM:
        return True
    if str(details.get("review_reason_code") or "").strip() == REASON_PSEUDONYM:
        return True
    return looks_like_descriptive_pseudonym(person_name)


def surname_inferred_from_relative(entry: dict[str, Any]) -> bool:
    """True when PersonExtract inferred a shared surname from a family reference."""
    val = entry.get("surname_inferred_from_relative")
    if val is True:
        return True
    if isinstance(val, str) and val.strip().lower() in {"true", "yes", "1"}:
        return True
    return False


def inferred_surname_from_review_message(message: str | None) -> bool:
    """Legacy rows may carry inferred-surname context only in ``review_message``."""
    text = str(message or "").strip().lower()
    if not text:
        return False
    return "inferred surname" in text or "surname inferred" in text


def person_inferred_surname_from_details(details: dict[str, Any]) -> bool:
    if surname_inferred_from_relative(details):
        return True
    return inferred_surname_from_review_message(
        details.get("review_message") if isinstance(details.get("review_message"), str) else None
    )


def review_reason_indicates_inferred_surname(reason: dict[str, Any]) -> bool:
    if str(reason.get("code") or "") != REASON_FIRST_NAME_ONLY:
        return False
    return inferred_surname_from_review_message(
        reason.get("message") if isinstance(reason.get("message"), str) else None
    )


def apply_inferred_surname_review_flag(
    entry: dict[str, Any],
    *,
    handling: ReviewHandling,
    reason_code: str | None,
    message: str | None,
) -> tuple[ReviewHandling, str | None, str | None]:
    """Force open-queue review for inferred surnames (same code as first-name-only)."""
    if not surname_inferred_from_relative(entry):
        return handling, reason_code, message
    if reason_code in AUTO_WAIVE_REASON_CODES:
        return handling, reason_code, message
    return (
        REVIEW_HANDLING_FLAG,
        REASON_FIRST_NAME_ONLY,
        message or _INFERRED_SURNAME_REVIEW_MESSAGE,
    )


def apply_non_person_review_override(
    name: str,
    *,
    handling: ReviewHandling,
    reason_code: str | None,
    message: str | None,
    title: str | None = None,
    affiliation: str | None = None,
) -> tuple[ReviewHandling, str | None, str | None]:
    """Route institutions, laws, and media outlets out of person linking."""
    if reason_code in AUTO_WAIVE_REASON_CODES:
        return handling, reason_code, message
    if not looks_like_non_person_entity(name, title=title, affiliation=affiliation):
        return handling, reason_code, message
    return (
        REVIEW_HANDLING_AUTO_DEFER,
        REASON_NOT_A_PERSON,
        message or default_review_message(REASON_NOT_A_PERSON),
    )


def apply_pseudonym_review_override(
    name: str,
    *,
    handling: ReviewHandling,
    reason_code: str | None,
    message: str | None,
) -> tuple[ReviewHandling, str | None, str | None]:
    """Route descriptive pseudonyms to defer (not stage-name link/create review)."""
    if reason_code in AUTO_WAIVE_REASON_CODES:
        return handling, reason_code, message
    if reason_code == REASON_FIRST_NAME_ONLY:
        return handling, reason_code, message
    if not looks_like_descriptive_pseudonym(name):
        return handling, reason_code, message
    return (
        REVIEW_HANDLING_FLAG,
        REASON_PSEUDONYM,
        message or default_review_message(REASON_PSEUDONYM),
    )


def apply_deterministic_review_overrides(
    name: str,
    *,
    handling: ReviewHandling,
    reason_code: str | None,
    message: str | None,
) -> tuple[ReviewHandling, str | None, str | None]:
    """Apply rule-based review when the model left ``review_handling`` as ``none``."""
    if handling != REVIEW_HANDLING_NONE:
        return handling, reason_code, message
    if looks_like_first_name_only_token(name):
        code = REASON_FIRST_NAME_ONLY
        return (
            REVIEW_HANDLING_FLAG,
            code,
            message or default_review_message(code),
        )
    return handling, reason_code, message


def finalize_review_fields_from_entry(entry: dict[str, Any]) -> dict[str, Any]:
    """Return review keys to merge onto a person entry (sets ``needs_review`` when flagged)."""
    name_raw = entry.get("name")
    name = name_raw.strip() if isinstance(name_raw, str) else ""
    handling, code, message = parse_review_fields_from_entry(entry)
    handling, code, message = apply_inferred_surname_review_flag(
        entry,
        handling=handling,
        reason_code=code,
        message=message,
    )
    if name:
        handling, code, message = apply_pseudonym_review_override(
            name,
            handling=handling,
            reason_code=code,
            message=message,
        )
    if name:
        title_raw = entry.get("title")
        aff_raw = entry.get("affiliation")
        title = title_raw.strip() if isinstance(title_raw, str) else None
        affiliation = aff_raw.strip() if isinstance(aff_raw, str) else None
        handling, code, message = apply_non_person_review_override(
            name,
            handling=handling,
            reason_code=code,
            message=message,
            title=title,
            affiliation=affiliation,
        )
    if name:
        handling, code, message = apply_deterministic_review_overrides(
            name,
            handling=handling,
            reason_code=code,
            message=message,
        )
    needs_review = handling == REVIEW_HANDLING_FLAG
    out: dict[str, Any] = {
        "review_handling": handling,
        "review_reason_code": code,
        "review_message": message,
        "needs_review": needs_review,
    }
    return out


def review_context_from_source_details(
    details: dict[str, Any] | None,
) -> tuple[ReviewHandling, str | None, str | None]:
    if not isinstance(details, dict):
        return REVIEW_HANDLING_NONE, None, None
    handling = _normalize_handling(details.get("review_handling"))
    code = _normalize_reason_code(details.get("review_reason_code"))
    message = _optional_message(details.get("review_message"))
    if code is not None and handling == REVIEW_HANDLING_NONE:
        handling = _handling_for_reason(code)
    return handling, code, message


def entry_people_bucket(entry: dict[str, Any]) -> str:
    """Map consolidated entry to worker people bucket (``ready`` vs ``needs_review``)."""
    if entry.get("needs_review") is True:
        return "needs_review"
    handling, code, _msg = parse_review_fields_from_entry(entry)
    if handling == REVIEW_HANDLING_FLAG:
        return "needs_review"
    status = entry.get("status")
    if isinstance(status, str) and status.strip().lower() == "needs_review":
        return "needs_review"
    _ = code
    return "ready"


def plan_includes_person_review_defer(
    plan_reasons: tuple[dict[str, Any], ...] | list[dict[str, Any]],
) -> bool:
    for r in plan_reasons:
        if not isinstance(r, dict):
            continue
        code = str(r.get("code") or "")
        if code in _VALID_REASON_CODES:
            return True
    return False


def plan_includes_auto_waive_person_review(
    plan_reasons: tuple[dict[str, Any], ...] | list[dict[str, Any]],
) -> bool:
    for r in plan_reasons:
        if isinstance(r, dict) and is_auto_waive_review_code(str(r.get("code") or "")):
            return True
    return False


def plan_includes_flag_person_review(
    plan_reasons: tuple[dict[str, Any], ...] | list[dict[str, Any]],
) -> bool:
    for r in plan_reasons:
        if isinstance(r, dict) and is_flag_review_code(str(r.get("code") or "")):
            return True
    return False


def plan_includes_defer_only_person_review(
    plan_reasons: tuple[dict[str, Any], ...] | list[dict[str, Any]],
) -> bool:
    for r in plan_reasons:
        if not isinstance(r, dict):
            continue
        code = str(r.get("code") or "")
        if code in AUTO_WAIVE_REASON_CODES:
            return True
        if code == REASON_PSEUDONYM:
            return True
        if code == REASON_FIRST_NAME_ONLY:
            if isinstance(r, dict) and review_reason_indicates_inferred_surname(r):
                continue
            return True
    return False


def person_source_details(person: Any) -> dict[str, Any]:
    raw = getattr(person, "source_details_json", None)
    return raw if isinstance(raw, dict) else {}


def person_review_reason_code_from_source(details: dict[str, Any]) -> str | None:
    _handling, code, _message = review_context_from_source_details(details)
    return code


def person_surname_inferred_from_source(person: Any) -> bool:
    return person_inferred_surname_from_details(person_source_details(person))


def person_review_recommends_defer_only(
    *,
    reason_code: str | None,
    source_details: dict[str, Any] | None = None,
    person_name: str | None = None,
) -> bool:
    """True when editors should defer (no link/create recommendation)."""
    details = source_details if isinstance(source_details, dict) else {}
    if person_inferred_surname_from_details(details):
        return False
    name = (person_name or "").strip()
    if not name and isinstance(details.get("name"), str):
        name = str(details.get("name")).strip()
    if name and person_name_is_descriptive_pseudonym(
        person_name=name,
        reason_code=reason_code,
        source_details=details,
    ):
        return True
    code = str(reason_code or "").strip()
    if code in AUTO_WAIVE_REASON_CODES:
        return True
    if code == REASON_PSEUDONYM:
        return True
    return code == REASON_FIRST_NAME_ONLY


def person_review_blocks_auto_materialize(
    *,
    reason_code: str | None,
    source_details: dict[str, Any] | None = None,
    person_name: str | None = None,
) -> bool:
    """True when ingest must not auto-create a canonical (review queue may still suggest create)."""
    details = source_details if isinstance(source_details, dict) else {}
    if person_inferred_surname_from_details(details):
        return True
    name = (person_name or "").strip()
    if name and person_name_is_descriptive_pseudonym(
        person_name=name,
        reason_code=reason_code,
        source_details=details,
    ):
        return True
    code = str(reason_code or "").strip()
    if code == REASON_STAGE_NAME_OR_ALIAS:
        return True
    return person_review_recommends_defer_only(
        reason_code=code,
        source_details=details,
        person_name=person_name,
    )
