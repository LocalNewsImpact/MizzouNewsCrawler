"""High-precision detection of obviously wrong location substrate-to-canonical links."""

from __future__ import annotations

import re
from typing import Any

from backfield_entities.canonical.jurisdiction import district_kind_keywords_conflict
from backfield_entities.canonical.link_matrix import types_are_comparable
from backfield_entities.ingest.geocode_cache.fingerprint import normalize_substrate_cache_query
from backfield_entities.ingest.geocode_cache.sanity import cache_hit_sane_for_substrate

_NON_ALNUM_RE = re.compile(r"[^a-z0-9]+")

_LOCATION_STOP_WORDS: frozenset[str] = frozenset(
    {
        "al",
        "ak",
        "az",
        "ar",
        "ca",
        "co",
        "ct",
        "de",
        "fl",
        "ga",
        "hi",
        "id",
        "il",
        "in",
        "ia",
        "ks",
        "ky",
        "la",
        "ma",
        "md",
        "me",
        "mi",
        "mn",
        "mo",
        "ms",
        "mt",
        "nc",
        "nd",
        "ne",
        "nh",
        "nj",
        "nm",
        "nv",
        "ny",
        "oh",
        "ok",
        "or",
        "pa",
        "ri",
        "sc",
        "sd",
        "tn",
        "tx",
        "ut",
        "va",
        "vt",
        "wa",
        "wi",
        "wv",
        "wy",
        "dc",
        "usa",
        "us",
        "st",
        "street",
        "ave",
        "avenue",
        "rd",
        "road",
        "blvd",
        "boulevard",
        "dr",
        "drive",
        "ln",
        "lane",
        "ct",
        "court",
        "pl",
        "place",
        "the",
        "of",
        "and",
        "chicago",
        "illinois",
    }
)


def normalize_location_alias_key(value: str | None) -> str:
    """Normalized alias key for location substrate names."""
    return normalize_substrate_cache_query(str(value or ""))


def _compare_key(text: str) -> str:
    return _NON_ALNUM_RE.sub(" ", (text or "").strip().lower()).strip()


def _first_segment_key(text: str) -> str:
    first = str(text or "").split(",")[0]
    return _compare_key(normalize_substrate_cache_query(first))


def _meaningful_location_tokens(text: str) -> frozenset[str]:
    key = _compare_key(text)
    if not key:
        return frozenset()
    return frozenset(
        token
        for token in key.split()
        if len(token) >= 2 and token not in _LOCATION_STOP_WORDS
    )


def _strip_leading_the(head: str) -> str:
    tokens = head.split()
    if len(tokens) > 1 and tokens[0] == "the":
        return " ".join(tokens[1:])
    return head


# Geographic feature words stripped when comparing place proper-name heads.
_LOCATION_FEATURE_WORDS: frozenset[str] = frozenset(
    {
        "river",
        "lake",
        "creek",
        "stream",
        "bay",
        "beach",
        "park",
        "forest",
        "grove",
        "trail",
        "bridge",
        "bridges",
        "dam",
        "canal",
        "island",
        "mountain",
        "mountains",
        "hills",
        "valley",
        "road",
        "street",
        "avenue",
        "boulevard",
        "highway",
    }
)


def _place_proper_head(text: str) -> str | None:
    """Leading proper-name token of the first comma segment, ignoring feature words."""
    head = _strip_leading_the(_first_segment_key(text))
    if not head:
        return None
    for token in head.split():
        if len(token) >= 2 and token not in _LOCATION_FEATURE_WORDS:
            return token
    return None


def location_place_heads_conflict(substrate_name: str, canonical_label: str) -> bool:
    """True when leading place proper names disagree (e.g. DuPage River vs Illinois River)."""
    if location_names_share_obvious_identity(substrate_name, canonical_label):
        return False
    sub_head = _place_proper_head(substrate_name)
    canon_head = _place_proper_head(canonical_label)
    if not sub_head or not canon_head:
        return False
    return sub_head != canon_head


def location_names_share_obvious_identity(
    substrate_name: str,
    canonical_label: str,
) -> bool:
    """True when names clearly refer to the same place despite type or tail variance."""
    if _compare_key(substrate_name) == _compare_key(canonical_label):
        return True

    sub_seg = _strip_leading_the(_first_segment_key(substrate_name))
    canon_seg = _strip_leading_the(_first_segment_key(canonical_label))
    if sub_seg and sub_seg == canon_seg and len(sub_seg) >= 4:
        return True
    sub_head_blob = _compare_key(str(substrate_name or "").split(",")[0])
    canon_head_blob = _compare_key(str(canonical_label or "").split(",")[0])
    if sub_head_blob and canon_head_blob:
        if len(sub_seg) >= 8 and len(canon_seg) >= 8:
            if sub_seg in canon_head_blob and len(sub_seg) >= 0.55 * len(sub_head_blob):
                return True
            if canon_seg in sub_head_blob and len(canon_seg) >= 0.55 * len(canon_head_blob):
                return True
    head_shared = _meaningful_location_tokens(
        str(substrate_name or "").split(",")[0]
    ) & _meaningful_location_tokens(str(canonical_label or "").split(",")[0])
    return len(head_shared) >= 2


_MUNICIPALITY_LOCATION_TYPES: frozenset[str] = frozenset({"city", "town", "village"})


def location_district_kind_conflict(
    *,
    substrate_texts: tuple[str | None, ...],
    substrate_location_type: str | None,
    canonical_texts: tuple[str | None, ...],
    canonical_location_type: str | None,
) -> bool:
    """True when a political-district pairing is an obvious kind error.

    Two deterministic signals:
    - a ``political_district`` row paired with a municipality (a district is never
      the same entity as its city, even when the display names match), and
    - district-kind keywords that disagree across the pair (judicial subcircuit vs
      congressional district vs ward vs state house/senate).
    """
    s_lt = (substrate_location_type or "").strip().lower()
    c_lt = (canonical_location_type or "").strip().lower()
    if s_lt != "political_district" and c_lt != "political_district":
        return False
    if s_lt == "political_district" and c_lt in _MUNICIPALITY_LOCATION_TYPES:
        return True
    if c_lt == "political_district" and s_lt in _MUNICIPALITY_LOCATION_TYPES:
        return True
    return district_kind_keywords_conflict(substrate_texts, canonical_texts)


def location_merge_pair_blocked(
    *,
    source_label: str,
    source_location_type: str | None,
    target_label: str,
    target_location_type: str | None,
) -> bool:
    """True when merging these canonicals would be an obvious scale/kind error.

    Blocks merges across deny-listed ``location_type`` pairs (e.g. a venue ``place``
    into its containing ``city``) unless the labels clearly name the same place —
    the identity escape hatch keeps mistyped rows of the same place mergeable.
    Political-district conflicts are blocked without the escape hatch: a district
    canonical labeled like its city is still not the city.
    """
    if location_district_kind_conflict(
        substrate_texts=(source_label,),
        substrate_location_type=source_location_type,
        canonical_texts=(target_label,),
        canonical_location_type=target_location_type,
    ):
        return True
    if types_are_comparable(source_location_type, target_location_type):
        return False
    return not location_names_share_obvious_identity(source_label, target_label)


def location_link_is_obvious_mismatch(
    *,
    substrate_name: str,
    substrate_normalized_name: str,
    substrate_location_type: str | None,
    components: dict[str, Any] | None,
    formatted_address: str | None,
    geometry_type: str | None,
    canonical_label: str,
    canonical_location_type: str | None,
    editorial_alias_keys: frozenset[str] | set[str] | None = None,
) -> bool:
    """True when a linked substrate row is clearly not the same place as the canonical label."""
    # District-kind conflicts flag before the editorial-alias and equal-name rescues:
    # the bad link itself often wrote the editorial alias (UI relink refreshes aliases),
    # and district rows misnamed after their city match the city label exactly.
    if location_district_kind_conflict(
        substrate_texts=(substrate_name, formatted_address),
        substrate_location_type=substrate_location_type,
        canonical_texts=(canonical_label,),
        canonical_location_type=canonical_location_type,
    ):
        return True
    norm_key = normalize_location_alias_key(substrate_normalized_name or substrate_name)
    alias_keys = editorial_alias_keys or frozenset()
    if norm_key and norm_key in alias_keys:
        return False
    if _compare_key(substrate_name) == _compare_key(canonical_label):
        return False

    location_text = str(substrate_name or "").strip()
    # Political districts use number/kind identity (and often ordinal vs numeral
    # wording); place-head conflict is too brittle there (Eighth Ward vs Ward 8).
    s_lt = (substrate_location_type or "").strip().lower()
    c_lt = (canonical_location_type or "").strip().lower()
    if "political_district" not in (s_lt, c_lt) and location_place_heads_conflict(
        location_text, canonical_label
    ):
        return True

    if cache_hit_sane_for_substrate(
        substrate_location_type=substrate_location_type,
        location_text=location_text,
        components=components,
        match_label=canonical_label,
        match_formatted_address=formatted_address,
        match_location_type=canonical_location_type,
        match_geometry_type=geometry_type,
    ):
        return False

    if location_names_share_obvious_identity(location_text, canonical_label):
        return False

    return True
