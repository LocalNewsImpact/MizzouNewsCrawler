"""Cleanup check finders."""
