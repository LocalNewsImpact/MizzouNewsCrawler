"""DBOutput node."""
