"""LLM OrganizationExtract node."""
