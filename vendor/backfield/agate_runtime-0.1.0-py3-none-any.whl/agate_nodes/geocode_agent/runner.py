"""GeocodeAgent runner for the Backfield executor."""

from __future__ import annotations

import logging
import os
from collections.abc import Callable
from typing import Any

from agate_runtime.context import AgateEnvContext
from agate_runtime.runners import default_context, run_geocode_agent_runtime

logger = logging.getLogger(__name__)


def _build_geocode_cache_bundle(
    project_id: int,
    stylebook_id: int | None,
) -> dict[str, Callable[..., Any]]:
    """Return callables for strict resolve + adjudication candidates + canonical materialization."""

    from backfield_db.session import get_engine
    from backfield_entities.ingest.geocode_cache.resolve import (
        build_geocode_cache_adjudication_candidates,
        materialize_canonical_match_dict,
        resolve_geocode_cache_strict_with_outcome,
    )
    from sqlmodel import Session

    def strict_resolve_with_outcome(
        location_text: str,
        location_type: str,
        components: dict[str, Any],
    ) -> dict[str, Any]:
        comps = components if isinstance(components, dict) else None
        with Session(get_engine()) as session:
            outcome = resolve_geocode_cache_strict_with_outcome(
                session,
                project_id=project_id,
                stylebook_id=stylebook_id,
                location_text=location_text,
                location_type=location_type,
                components=comps,
            )
            return {
                "match_dict": outcome.match_dict,
                "ambiguous_tier1": outcome.ambiguous_tier1,
                "tier2_sanity_failed": outcome.tier2_sanity_failed,
            }

    def adjudication_candidates(
        location_text: str,
        location_type: str,
        components: dict[str, Any],
    ) -> list[dict[str, Any]]:
        if stylebook_id is None:
            return []
        comps = components if isinstance(components, dict) else None
        with Session(get_engine()) as session:
            return build_geocode_cache_adjudication_candidates(
                session,
                stylebook_id=stylebook_id,
                location_text=location_text,
                location_type=location_type,
                components=comps,
            )

    def materialize_canonical(
        canonical_id: str,
        substrate_location_type: str | None = None,
        location_text: str | None = None,
        components: dict[str, Any] | None = None,
    ) -> dict[str, Any] | None:
        if stylebook_id is None:
            return None
        with Session(get_engine()) as session:
            return materialize_canonical_match_dict(
                session,
                stylebook_id=stylebook_id,
                canonical_id=str(canonical_id).strip(),
                substrate_location_type=substrate_location_type,
                location_text=location_text,
                components=components if isinstance(components, dict) else None,
            )

    return {
        "strict_resolve_with_outcome": strict_resolve_with_outcome,
        "adjudication_candidates": adjudication_candidates,
        "materialize_canonical": materialize_canonical,
    }


def attach_geocode_cache_bundle(
    ctx: AgateEnvContext,
    *,
    use_cache: bool,
    stylebook_id: int | None,
) -> None:
    """Attach DB cache closures to ``ctx.metadata`` when cache is enabled in the worker."""
    if not use_cache:
        return
    raw_pid = os.getenv("BACKFIELD_PROJECT_ID")
    if not raw_pid:
        return
    try:
        pid = int(raw_pid)
    except (TypeError, ValueError):
        logger.debug(
            "Geocode DB cache skipped: invalid BACKFIELD_PROJECT_ID or stylebook id (%r, %r)",
            raw_pid,
            stylebook_id,
        )
        return

    from backfield_db.session import get_engine
    from backfield_entities.catalog.resolve import resolve_stylebook_id_for_project_id
    from sqlmodel import Session

    with Session(get_engine()) as session:
        sid = resolve_stylebook_id_for_project_id(session, pid)
    if stylebook_id is not None and int(stylebook_id) != sid:
        raise ValueError(
            "GeocodeAgent Stylebook does not match the project's assigned Stylebook"
        )

    ctx.metadata["geocode_cache_bundle"] = _build_geocode_cache_bundle(pid, sid)


def run_geocode_agent(params: dict[str, Any], inputs: dict[str, Any]) -> dict[str, Any]:
    return run_geocode_agent_runtime(params, inputs, default_context())
