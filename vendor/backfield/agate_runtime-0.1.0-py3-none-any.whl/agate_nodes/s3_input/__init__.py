"""S3Input node."""
