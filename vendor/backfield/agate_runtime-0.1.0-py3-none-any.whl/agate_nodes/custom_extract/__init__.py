"""Custom Extract node package."""
