"""JSONInput node."""
