"""LLM PlaceExtract."""
