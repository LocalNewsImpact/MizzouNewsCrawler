"""Output node."""
