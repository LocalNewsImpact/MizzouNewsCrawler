"""S3Output node."""
